<?php

namespace App\Http\Controllers;

use App\Models\QuoteRequestBatch;
use App\Services\QuotePdfDataBuilder;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

class QuoteRequestPdfDataController extends Controller
{
    public function __construct(
        protected QuotePdfDataBuilder $quotePdfDataBuilder
    ) {}

    /**
     * Signed URL (guest or anyone with the link until expiry). Use route middleware `signed`.
     */
    public function show(QuoteRequestBatch $batch): JsonResponse
    {
        return response()->json($this->quotePdfDataBuilder->build($batch));
    }

    /**
     * Authenticated customer: only their own batches.
     */
    public function showForAccount(QuoteRequestBatch $batch): JsonResponse
    {
        if ($batch->user_id === null || $batch->user_id !== (int) auth()->id()) {
            abort(Response::HTTP_NOT_FOUND);
        }

        return response()->json($this->quotePdfDataBuilder->build($batch));
    }
}
